let myInput = {
    template: `<div><h5>我的input框</h5><input v-model="value"/></div>`,
    data() {
        return {
            value: ''
        }
    }
}
